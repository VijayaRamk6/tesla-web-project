 <section>
        <div class="h2-hero">
			<div class="container">
				<div class="row">
					<div class="h2-hero-inn">
						<div class="h2-hero-left">
						<div class="ed-ban-tit">
						<div class="ed-ban-tit-1">
							<h1>Welcome to 369Tesla - <span>Education</span></h1>
						</div>
						<div class="ed-ban-tit-2">
							<h4><span class="ed-bann-line"></span><span class="ed-bann-line1"></span>Londan</h4>
						</div>
						<div class="ed-ban-tit-3">
							<div class="ed-ban-tit-3-com ed-ban-tit-31">
								<div class="ed-sprit ed-ban-cal-le">
									<span>24</span><span>feb</span>
								</div>
								<div class="ed-ban-cal-ri">
									<a href="#"><span>Admission 2024</span></a><span>New York City</span>
								</div>
							</div>
							<div class="ed-ban-tit-3-com ed-ban-tit-32">
								<div class="ed-sprit ed-ban-cal-le">
									<span>05</span><span>apr</span>
								</div>
								<div class="ed-ban-cal-ri">
									<a href="#"><span>College farewell</span></a><span>Chicago</span>
								</div>
							</div>
							<div class="ed-ban-tit-3-com ed-ban-tit-31">
								<div class="ed-sprit ed-ban-cal-le">
									<span>18</span><span>jul</span>
								</div>
								<div class="ed-ban-cal-ri">
									<a href="#"><span>Sports event</span></a><span>San Francisco</span>
								</div>
							</div>
							<div class="ed-ban-tit-3-com ed-ban-tit-32">
								<div class="ed-sprit ed-ban-cal-le">
									<span>26</span><span>sep</span>
								</div>
								<div class="ed-ban-cal-ri">
									<a href="#"><span>Seminars</span></a><span>Los Angeles</span>
								</div>
							</div>
						</div>
					</div>
						</div>
						<div class="h2-hero-right">
<div class="ed-ref-form">
						<div class="ed-ref-form-inn">
<div class="map-head">
						<p>Register for the</p>
						<h2>Admissions</h2> <span class="footer-ser-re">fill below details</span> </div>
							<form>
								<ul>
									<li>
										<input type="text" required="">
										<span class="floating-label">Name</span>
									</li>
									<li>
										<input type="email" required="">
										<span class="floating-label">Email ID</span>
									</li>
									<li>
										<input type="number" required="">
										<span class="floating-label">Phone number</span>
									</li>
									<li>
										<input type="text" required="">
										<span class="floating-label">City</span>
									</li>
																		
									<li>
										<input type="submit" value="Register Now">
									</li>
								</ul>
							</form>
						</div>
					</div>
						</div>
					</div>
				</div>
			</div>
		</div>
    </section>
