<!DOCTYPE php>
<php lang="en">


<?php include"about/head.php" ?>

<body>

    <!-- MOBILE MENU -->
    <?php include"about/mobile menu.php" ?>

    <!--HEADER SECTION-->
    <?php include"about/header.php" ?>
    <!--END HEADER SECTION-->

    <!--SECTION START-->
    <?php include"about/section.php" ?>
    <!--SECTION END-->


    <!--SECTION START-->
    <?php include"about/section1.php" ?>
    <!--SECTION END-->

    <!--HEADER SECTION-->
    <?php include"about/header1.php" ?>
    <!--END HEADER SECTION-->

    <!--HEADER SECTION-->
    <?php include"about/header3.php" ?>
    <!--END HEADER SECTION-->

    <!--SECTION LOGIN, REGISTER AND FORGOT PASSWORD-->
    <?php include"about/login.php" ?>

    <!--Import jQuery before materialize.js-->
    <?php include"about/js.php" ?>
</body>


</php>