<section>
    <div class="container com-sp pad-bot-70 pg-inn">
        <div class="row">
            <div class="cor">
                <div class="col-md-3">
                    <div class="cor-top-deta cor-side-com">
                        <div class="cor-top-deta">
                            <div class="ho-st-login cor-apply field-com">
                                <div class="col s12">
                                    <form class="col s12" id="registration-form" action="db/regg.php" method="post">
                                        <fieldset>
                                            <div class="form-group">
                                                <input class="form-control" placeholder="First Name" name="Username"
                                                    type="text" autofocus>
                                            </div>
                                            <div class="form-group">
                                                <input class="form-control" placeholder="Last Name" name="Lastname"
                                                    type="text" autofocus>
                                            </div>
                                            <div class="form-group">
                                                <input class="form-control" placeholder="Date of Birth" name="DOB"
                                                    type="date" autofocus>
                                            </div>
                                            <div class="form-group">
                                                <input class="form-control" placeholder="Place" name="Place" type="text"
                                                    autofocus>
                                            </div>
                                            <div class="form-group">
                                                <input class="form-control" placeholder="Area" name="Area" type="text"
                                                    autofocus>
                                            </div>
                                            <div class="form-group">
                                                <input class="form-control" placeholder="District" name="District"
                                                    type="text" autofocus>
                                            </div>
                                            <div class="form-group">
                                                <input class="form-control" placeholder="Email" name="email"
                                                    type="email" autofocus>
                                            </div>
                                            <div class="form-group">
                                                <input class="form-control" placeholder="Phone" name="phone" type="tel"
                                                    autofocus>
                                            </div>
                                            <div class="form-row">
                                                <div class="name">Subject</div>
                                                <div class="value">
                                                    <div class="input-group">
                                                        <div class="rs-select2 js-select-simple select--no-search">
                                                            <select name="subject">
                                                                <option disabled selected>Choose option</option>
                                                                <option>NEET</option>
                                                                <option>IIT-JEE</option>
                                                                <option>SET NET</option>
                                                                <option>NTSE</option>
                                                                <option>TRB CS</option>
                                                                <option>TRB COMMERCE</option>
                                                                <option>BANKING</option>
                                                                <option>TNPSC</option>
                                                                <option>RRB</option>
                                                            </select>
                                                            <div class="select-dropdown"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <button type="submit">Submit</button>
                                        </fieldset>
                                    </form>
                                    <div id="success-message">
                                        <?php
                                        if (isset($_GET['success']) && $_GET['success'] == 'true') {
                                            echo 'Data inserted successfully!';
                                        }
                                        ?>
                                    </div>

                                    <script>
                                        // JavaScript function to clear form fields
                                        function clearFormFields() {
                                            document.getElementById("registration-form").reset();
                                        }

                                        // JavaScript function to validate the form
                                        function validateForm() {
                                            var firstname = document.forms["registration-form"]["Username"].value;

                                            // Check if the First Name field is empty
                                            if (firstname == "") {
                                                alert("First Name must be filled out");
                                                return false;
                                            }
                                            // You can add more validation here if needed

                                            // Form is valid, clear form fields
                                            clearFormFields();
                                            return true;
                                        }
                                    </script>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="cor-side-com">
                        <div class="">
                            <div class="de-left-tit">
                                <h4>Upcoming Event</h4>
                            </div>
                        </div>
                        <div class="ho-event">
                            <ul>
                                <li>
                                    <div class="ho-ev-link ho-ev-link-full">
                                        <a href="#">
                                            <h4>TNPSC</h4>
                                        </a>
                                        <p>For All Students</p>
                                        <span>9:15 am – 5:00 pm</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="ho-ev-link ho-ev-link-full">
                                        <a href="#">
                                            <h4>NEET</h4>
                                        </a>
                                        <p>The total marks for the exam are 720</p>
                                        <span>9:15 am – 5:00 pm</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="ho-ev-link ho-ev-link-full">
                                        <a href="#">
                                            <h4>JEE</h4>
                                        </a>
                                        <p>JEE Advanced is conducted by one of the IITs on a rotational basis.</p>
                                        <span>9:15 am – 5:00 pm</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="ho-ev-link ho-ev-link-full">
                                        <a href="#">
                                            <h4>CS</h4>
                                        </a>
                                        <p>regular clases and tests for cs students.</p>
                                        <span>9:15 am – 5:00 pm</span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="cor-mid-img">
                        <img src="images/course.jpg" alt="">
                    </div>
                    <div class="cor-con-mid">
                        <div class="cor-p1">
                            <h2>Biological Sciences</h2>
                            <span>Category: Software Testing</span>
                            <div class="share-btn">
                                <ul>
                                    <li><a href="#"><i class="fa fa-facebook fb1"></i> Share On Facebook</a>
                                    </li>
                                    <li><a href="#"><i class="fa fa-twitter tw1"></i> Share On Twitter</a>
                                    </li>
                                    <li><a href="#"><i class="fa fa-google-plus gp1"></i> Share On Google Plus</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="cor-p4">
                            <h3>Course Details:</h3>
                            <p>369Tesla is a distinguished educational institution committed to nurturing academic
                                excellence
                                and empowering students for success in highly competitive examinations. We offer
                                comprehensive
                                coaching programs for NEET, JEE, TNPSC, and CS, providing students with the knowledge,
                                skills,
                                and confidence they need to excel in these challenging tests. Our dedicated faculty,
                                state-of-the-art facilities,
                                and a student-centric approach ensure that aspiring medical, engineering, government
                                job, and company secretaryship
                                candidates receive top-notch guidance and support.
                                dreams and secure a promising future in their chosen fields.</p>
                            <p> At 369Tesla, we believe in unlocking the full potential of our students,
                                helping them achieve their.</p>
                        </div>
                        <div class="cor-p5">
                            <h3>Course Syllabus</h3>
                            <ul class="nav nav-tabs">
                                <li class="active"><a data-toggle="tab" href="#home">
                                        <img src="images/icon/cor4.png" alt=""> <span>Requirements</span></a>
                                </li>
                                <li><a data-toggle="tab" href="#menu1"><img src="images/icon/cor3.png"
                                            alt=""><span>Fees</span></a></li>
                                <li><a data-toggle="tab" href="#menu2"><img src="images/icon/cor1.png"
                                            alt=""><span>Student Profile</span></a></li>
                                <li><a data-toggle="tab" href="#menu2"><img src="images/icon/cor5.png" alt=""><span>How
                                            to Apply</span></a></li>
                            </ul>

                            <div class="tab-content">
                                <div id="home" class="tab-pane fade in active">
                                    <h4>Home</h4>
                                    <p>Our primary goal is to empower aspiring students in their pursuit of success in
                                        competitive exams like NEET, JEE, TNPSC, and CS. </p>
                                    <p> At 369 Tesla, we believe that quality education is the key to unlocking one's
                                        potential and achieving their dreams. </p>
                                </div>
                                <div id="menu1" class="tab-pane fade">
                                    <h4>Menu 1</h4>
                                    <p>Some content in menu 1.</p>
                                </div>
                                <div id="menu2" class="tab-pane fade">
                                    <h4>Menu 2</h4>
                                    <p>Some content in menu 2.</p>
                                </div>
                            </div>
                        </div>

                        <div class="cor-p6">
                            <h3>Student Reviews</h3>
                            <div class="cor-p6-revi">
                                <div class="cor-p6-revi-left">
                                    <img src="images/4.jpg" alt="">
                                </div>
                                <div class="cor-p6-revi-right">
                                    <h4>harish aravind</h4>
                                    <span>Rating: ⭐⭐⭐⭐⭐ (5/5)</span>
                                    <p>I can't express enough how grateful I am to be a student at 369 Tesla. My first
                                        year here has been nothing short of exceptional. </p>
                                </div>
                            </div>
                            <div class="cor-p6-revi">
                                <div class="cor-p6-revi-left">
                                    <img src="images/4.jpg" alt="">
                                </div>
                                <div class="cor-p6-revi-right">
                                    <h4>mohammed bilal</h4>
                                    <span>Rating: ⭐⭐⭐⭐⭐ (5/5)</span>
                                    <p>The professors make complex concepts easy to understand, and their passion for
                                        teaching is evident in every lecture.</p>
                                </div>
                            </div>
                            <div class="cor-p6-revi">
                                <div class="cor-p6-revi-left">
                                    <img src="images/4.jpg" alt="">
                                </div>
                                <div class="cor-p6-revi-right">
                                    <h4>gowshick sidharth</h4>
                                    <span>Rating: ⭐⭐⭐⭐⭐ (5/5)</span>
                                    <p>What sets 369 Tesla apart is the sense of community. I've had the opportunity to
                                        collaborate with fellow students on projects, and the teamwork skills I've
                                        gained are invaluable.</p>
                                </div>
                            </div>
                            <div class="cor-p6-revi">
                                <div class="cor-p6-revi-left">
                                    <img src="images/4.jpg" alt="">
                                </div>
                                <div class="cor-p6-revi-right">
                                    <h4>spartan isravel</h4>
                                    <span>Rating: ⭐⭐⭐⭐ (4/5)</span>
                                    <p>It's more than just an institution; it's a place where dreams are nurtured and
                                        futures are shaped. I can't wait to see what the rest of my journey here holds!
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="cor-p6">
                            <h3>Write Reviews</h3>
                            <div class="cor-p7-revi">
                                <form class="col s12">
                                    <div class="row">
                                        <div class="input-field col s6">
                                            <input type="text" class="validate">
                                            <label>Name</label>
                                        </div>
                                        <div class="input-field col s6">
                                            <input type="text" class="validate">
                                            <label>Email id</label>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-field col s12">
                                            <textarea class="materialize-textarea"></textarea>
                                            <label>Message</label>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-field col s12">
                                            <input type="submit" value="Submit"
                                                class="waves-effect waves-light btn-book">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="cor-side-com">
                        <div class="ho-ev-latest ho-ev-latest-bg-3">
                            <div class="ho-lat-ev">
                                <h4>Student Login</h4>
                                <p>Student area velit convallis venenatis lacus quis, efficitur lectus.</p>
                            </div>
                        </div>
                        <div class="ho-st-login">
                            <div class="col s12">
                                <form class="col s12">
                                    <div class="row">
                                        <div class="input-field col s12">
                                            <input type="text" class="validate">
                                            <label>Student user name</label>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-field col s12">
                                            <input type="password" class="validate">
                                            <label>Password</label>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="input-field col s12">
                                            <input type="submit" value="Login"
                                                class="waves-effect waves-light light-btn">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="cor-side-com">
                        <div class="ho-ev-latest ho-ev-latest-bg-2">
                            <div class="ho-lat-ev">
                                <a href="#">
                                    <h4>Job Vacants</h4>
                                    <p>Nulla at velit convallis, venenatis lacus quis, efficitur lectus.</p>
                                </a>
                            </div>
                        </div>
                        <div class="ho-ev-latest in-ev-latest-bg-1">
                            <div class="ho-lat-ev">
                                <a href="#">
                                    <h4>Job Vacants</h4>
                                    <p>Nulla at velit convallis, venenatis lacus quis, efficitur lectus.</p>
                                </a>
                            </div>
                        </div>
                        <div class="ho-ev-latest in-ev-latest-bg-1">
                            <div class="ho-lat-ev">
                                <a href="#">
                                    <h4>Job Vacants</h4>
                                    <p>Nulla at velit convallis, venenatis lacus quis, efficitur lectus.</p>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>