 <section>
        <div class="ed-res-bg">
		<div class="container com-sp pad-bot-70 ed-res-bg">
            <div class="row">
                <div class="cor about-sp">
                    <div class="ed-rsear">
                        <div class="ed-rsear-in">
                            <ul>
                                <li>
									<div class="ed-rese-grid">
										<div class="ed-rsear-img ed-faci-full-top">
											<img src="images/facilities/1.jpg" alt="">
										</div>
										<div class="ed-rsear-dec ed-faci-full-bot">
											<h4><a href="facilities-detail.php">Design and Technology Suite</a></h4>
											<p>The Design and Technology Suite is an ensemble of various specialist areas and rooms which offer students the potential to explore a variety of design </p>
											<a href="facilities-detail.php" class="read-line-btn">Read more</a>
										</div>
									</div>
                                </li>
                                <li>
									<div class="ed-rese-grid">
										<div class="ed-rsear-img ed-faci-full-top">
											<img src="images/facilities/2.jpg" alt="">
										</div>
										<div class="ed-rsear-dec ed-faci-full-bot">
											<h4><a href="facilities-detail.php">Science Laboratories</a></h4>
											<p>The Design and Technology Suite is an ensemble of various specialist areas and rooms which offer students the potential to explore a variety of design </p>
											<a href="facilities-detail.php" class="read-line-btn">Read more</a>
										</div>
									</div>
                                </li>
                                <li>
									<div class="ed-rese-grid">
										<div class="ed-rsear-img ed-faci-full-top">
											<img src="images/facilities/3.jpg" alt="">
										</div>
										<div class="ed-rsear-dec ed-faci-full-bot">
											<h4><a href="facilities-detail.php">Multi-Purpose Sports Hall</a></h4>
											<p>The Design and Technology Suite is an ensemble of various specialist areas and rooms which offer students the potential to explore a variety of design </p>
											<a href="facilities-detail.php" class="read-line-btn">Read more</a>
										</div>
									</div>
                                </li>
                                <li>
									<div class="ed-rese-grid">
										<div class="ed-rsear-img ed-faci-full-top">
											<img src="images/facilities/4.jpg" alt="">
										</div>
										<div class="ed-rsear-dec ed-faci-full-bot">
											<h4><a href="facilities-detail.php">Design and Technology Suite</a></h4>
											<p>The Design and Technology Suite is an ensemble of various specialist areas and rooms which offer students the potential to explore a variety of design </p>
											<a href="facilities-detail.php" class="read-line-btn">Read more</a>
										</div>
									</div>
                                </li>
                                <li>
									<div class="ed-rese-grid">
										<div class="ed-rsear-img ed-faci-full-top">
											<img src="images/facilities/5.jpg" alt="">
										</div>
										<div class="ed-rsear-dec ed-faci-full-bot">
											<h4><a href="facilities-detail.php">Music Suites and En-suite Practice Rooms</a></h4>
											<p>The Design and Technology Suite is an ensemble of various specialist areas and rooms which offer students the potential to explore a variety of design </p>
											<a href="facilities-detail.php" class="read-line-btn">Read more</a>
										</div>
									</div>
                                </li>
                                <li>
									<div class="ed-rese-grid">
										<div class="ed-rsear-img ed-faci-full-top">
											<img src="images/facilities/6.jpg" alt="">
										</div>
										<div class="ed-rsear-dec ed-faci-full-bot">
											<h4><a href="facilities-detail.php">Workshop Technology Suite</a></h4>
											<p>The Design and Technology Suite is an ensemble of various specialist areas and rooms which offer students the potential to explore a variety of design </p>
											<a href="facilities-detail.php" class="read-line-btn">Read more</a>
										</div>
									</div>
                                </li>
                                <li>
									<div class="ed-rese-grid">
										<div class="ed-rsear-img ed-faci-full-top">
											<img src="images/facilities/7.jpg" alt="">
										</div>
										<div class="ed-rsear-dec ed-faci-full-bot">
											<h4><a href="facilities-detail.php">Medical Room</a></h4>
											<p>The Design and Technology Suite is an ensemble of various specialist areas and rooms which offer students the potential to explore a variety of design </p>
											<a href="facilities-detail.php" class="read-line-btn">Read more</a>
										</div>
									</div>
                                </li>
                                <li>
									<div class="ed-rese-grid">
										<div class="ed-rsear-img ed-faci-full-top">
											<img src="images/facilities/8.jpg" alt="">
										</div>
										<div class="ed-rsear-dec ed-faci-full-bot">
											<h4><a href="facilities-detail.php">Indoor and Outdoor Eating Areas</a></h4>
											<p>The Design and Technology Suite is an ensemble of various specialist areas and rooms which offer students the potential to explore a variety of design </p>
											<a href="facilities-detail.php" class="read-line-btn">Read more</a>
										</div>
									</div>
                                </li>
                                <li>
									<div class="ed-rese-grid">
										<div class="ed-rsear-img ed-faci-full-top">
											<img src="images/facilities/9.jpg" alt="">
										</div>
										<div class="ed-rsear-dec ed-faci-full-bot">
											<h4><a href="facilities-detail.php">Recreational Areas</a></h4>
											<p>The Design and Technology Suite is an ensemble of various specialist areas and rooms which offer students the potential to explore a variety of design </p>
											<a href="facilities-detail.php" class="read-line-btn">Read more</a>
										</div>
									</div>
                                </li>
                                <li>
									<div class="ed-rese-grid">
										<div class="ed-rsear-img ed-faci-full-top">
											<img src="images/facilities/10.jpg" alt="">
										</div>
										<div class="ed-rsear-dec ed-faci-full-bot">
											<h4><a href="facilities-detail.php">Drama Studio</a></h4>
											<p>The Design and Technology Suite is an ensemble of various specialist areas and rooms which offer students the potential to explore a variety of design </p>
											<a href="facilities-detail.php" class="read-line-btn">Read more</a>
										</div>
									</div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="ed-about-sec1">
                        <div class="col-md-6"></div>
                        <div class="col-md-6"></div>
                    </div>
                </div>
            </div>
        </div>
		</div>
    </section>