<section>
        <div class="head-2">
            <div class="container">
                <div class="head-2-inn head-2-inn-padd-top">
                    <h1>List of College Facilities</h1>
                    <p>Fusce id sem at ligula laoreet hendrerit venenatis sed purus. Ut pellentesque maximus lacus, nec pharetra augue.</p>
                    <div class="event-head-sub">
                        <ul>
                            <li>Topic: Global warming</li>
                            <li>Time: 09:15 am – 5:00 pm</li>
                            <li>Location: Illunois</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>	