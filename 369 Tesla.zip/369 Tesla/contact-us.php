<!DOCTYPE php>
<php lang="en">

<?php include"contact-us/head.php" ?>



<body>

    <!-- MOBILE MENU -->
    <?php include"contact-us/mobile menu.php" ?>
    <!--HEADER SECTION-->
    <?php include"contact-us/header.php" ?>
    <!--END HEADER SECTION-->

    <!--SECTION START-->
    <?php include"contact-us/section.php" ?>
    <!--SECTION END-->

    <?php include"contact-us/sec map.php" ?>

    <!--SECTION START-->
    <?php include"contact-us/section1.php" ?>
    <!--SECTION END-->

    <!--HEADER SECTION-->
    <?php include"contact-us/header1.php" ?>
    <!--END HEADER SECTION-->

    <!--HEADER SECTION-->
   
    <!--END HEADER SECTION-->

    <!--SECTION LOGIN, REGISTER AND FORGOT PASSWORD-->
    <?php include"contact-us/login.php" ?>
    <!--Import jQuery before materialize.js-->
    <?php include"contact-us/js.php" ?>
</body>


</php>