<!DOCTYPE php>
<php>
<body>
<?php include"sdb-course-edit/body.php" ?>
</body>
</php>
