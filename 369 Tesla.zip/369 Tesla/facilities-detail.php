<!DOCTYPE php>
<php lang="en">

<?php include"facilities-detail/head.php" ?>

<body>

    <!-- MOBILE MENU -->
    <?php include"facilities-detail/mobile menu.php" ?>
    <!--HEADER SECTION-->
    <?php include"facilities-detail/header.php" ?>
    <!--END HEADER SECTION-->

	<?php include"facilities-detail/sec.php" ?>
	
    <!--SECTION START-->
    <?php include"facilities-detail/section.php" ?>
    <!--SECTION END-->


    <!--SECTION START-->
    <?php include"facilities-detail/section1.php" ?>
    <!--SECTION END-->

    <!--HEADER SECTION-->
    <?php include"facilities-detail/header1.php" ?>
    <!--END HEADER SECTION-->

    <!--HEADER SECTION-->
    <?php include"facilities-detail/header2.php" ?>
    <!--END HEADER SECTION-->

    <!--SECTION LOGIN, REGISTER AND FORGOT PASSWORD-->
    <?php include"facilities-detail/login.php" ?>
    <!--Import jQuery before materialize.js-->
    <?php include"facilities-detail/js.php" ?>
</body>


</php>