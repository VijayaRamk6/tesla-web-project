

<section id="map">
  <div class="row contact-map">
    <!-- IFRAME: GET YOUR LOCATION FROM GOOGLE MAP -->
    <iframe
      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3934.8938415344116!2d77.3485944!3d10.0039601!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b070d1cb5d80937%3A0xec8d3db2b860606c!2s369%20Tesla%20Academy!5e0!3m2!1sen!2sin!4v1540278722043"
      width="100%" height="450" frameborder="0" style="border: 0; pointer-events: none;" allowfullscreen=""></iframe>
    <div class="container">
      <div class="overlay-contact footer-part footer-part-form">
        <div class="map-head">
          <p>Send Us Now</p>
          <h2>GetIn Touch</h2> <span class="footer-ser-re">Service Request Form</span>
        </div>
        <!-- ENQUIRY FORM -->
        
        <?php include"contact-us/form.html" ?>
      </div>
    </div>
  </div>
</section>
