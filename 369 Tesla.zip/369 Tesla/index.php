<!DOCTYPE php>
<php lang="en">


<?php include"index/head.php" ?>

<body>

    <!-- MOBILE MENU -->
    <?php include"index/mobile menu.php" ?>

    <!--HEADER SECTION-->
    <?php include"index/header.php" ?>
    <!--END HEADER SECTION-->
  
    <!-- SLIDER -->
    <?php include"index/slider.php" ?>

    <!-- QUICK LINKS -->
    <?php include"index/quick links.php" ?>

    <!-- DISCOVER MORE -->
    <?php include"index/discover.php" ?>

    <!-- POPULAR COURSES -->
    <?php include"index/popular.php" ?>

    <!-- UPCOMING EVENTS -->
    <?php include"index/upcomming.php" ?>

    <!-- NEWS AND EVENTS -->
    <?php include"index/news.php" ?>

    <!-- FOOTER COURSE BOOKING -->
    <?php include"index/footer courses.php" ?>

    <!-- FOOTER -->
    <?php include"index/footer.php" ?>

    <!-- COPY RIGHTS -->
    <?php include"index/copy rights.php" ?>

    <!--SECTION LOGIN, REGISTER AND FORGOT PASSWORD-->
    <?php include"index/login.php" ?>
    <!-- SOCIAL MEDIA SHARE -->
    <?php include"index/social media.php" ?>
    <!--Import jQuery before materialize.js-->
    <?php include"index/js.php" ?>
</body>

</php>