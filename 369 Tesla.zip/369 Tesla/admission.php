<!DOCTYPE php>
<php lang="en">

<?php include"admission/head.php" ?>


<body>

    <!-- MOBILE MENU -->
    <?php include"admission/mobile menu.php" ?>

    <!--HEADER SECTION-->
    <?php include"admission/header.php" ?>
    <!--END HEADER SECTION-->

    <!--SECTION START-->
    <?php include"admission/section start.php" ?>
    <!--SECTION END-->


    <!--SECTION START-->
    <?php include"admission/section start1.php" ?>
    <!--SECTION END-->

    <!--HEADER SECTION-->
    <?php include"admission/header1.php" ?>
    <!--END HEADER SECTION-->

    <!--HEADER SECTION-->
    <?php include"admission/header2.php" ?>
    <!--END HEADER SECTION-->

    <!--SECTION LOGIN, REGISTER AND FORGOT PASSWORD-->
    <?php include"admission/login.php" ?>

    <!--Import jQuery before materialize.js-->
    <?php include"admission/js.php" ?>
</body>


</php>