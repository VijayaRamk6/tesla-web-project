<!DOCTYPE php>
<php lang="en">


<?php include"blog-details/head.php" ?>

<body>

    <!-- MOBILE MENU -->
    <?php include"blog-details/mobile menu.php" ?>
    <!--HEADER SECTION-->
    <?php include"blog-details/header.php" ?>
    <!--END HEADER SECTION-->

    <!--SECTION START-->
    <?php include"blog-details/section.php" ?>
    <!--SECTION END-->


    <!--SECTION START-->
    <?php include"blog-details/section1.php" ?>
    <!--SECTION END-->

    <!--HEADER SECTION-->
    <?php include"blog-details/header1.php" ?>
    <!--END HEADER SECTION-->

    <!--HEADER SECTION-->
    <?php include"blog-details/header2.php" ?>
    <!--END HEADER SECTION-->

    <!--SECTION LOGIN, REGISTER AND FORGOT PASSWORD-->
    <?php include"blog-details/login.php" ?>

    <!--Import jQuery before materialize.js-->
    <?php include"blog-details/js.php" ?>
</body>


</php>