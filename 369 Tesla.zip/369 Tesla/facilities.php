<!DOCTYPE php>
<php lang="en">


<?php include"facilities/head.php" ?>

<body>

    <!-- MOBILE MENU -->
    <?php include"facilities/mobile menu.php" ?>

    <!--HEADER SECTION-->
    <?php include"facilities/header.php" ?>
    <!--END HEADER SECTION-->

    <?php include"facilities/sec.php" ?>
	
    <!--SECTION START-->
    <?php include"facilities/section.php" ?>
    <!--SECTION END-->


    <!--SECTION START-->
    <?php include"facilities/section1.php" ?>
    <!--SECTION END-->

    <!--HEADER SECTION-->
    <?php include"facilities/header1.php" ?>
    <!--END HEADER SECTION-->

    <!--HEADER SECTION-->
    <?php include"facilities/header2.php" ?>
    <!--END HEADER SECTION-->

    <!--SECTION LOGIN, REGISTER AND FORGOT PASSWORD-->
    <?php include"facilities/login.php" ?>

    <!--Import jQuery before materialize.js-->
    <?php include"facilities/js.php" ?>
</body>


</php>