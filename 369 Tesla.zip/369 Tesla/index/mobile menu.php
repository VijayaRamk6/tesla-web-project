   <section>
        <div class="ed-mob-menu">
            <div class="ed-mob-menu-con">
                <div class="ed-mm-left">
                    <div class="wed-logo">
                        <a href="index-2.php"><img src="images/logo.png" alt="" />
						</a>
                    </div>
                </div>
                <div class="ed-mm-right">
                    <div class="ed-mm-menu">
                        <a href="#!" class="ed-micon"><i class="fa fa-bars"></i></a>
                        <div class="ed-mm-inn">
                            <a href="#!" class="ed-mi-close"><i class="fa fa-times"></i></a>
                            <h4>All Courses</h4>
                            <ul>
                            <li><a href="course-details.php">computer Science</a></li>
                                            <li><a href="course-details.php">IIT</a></li>
                                            <li><a href="course-details.php">JEE</a></li>
                                            <li><a href="course-details.php">NEET</a></li>
                                            <li><a href="course-details.php">TNPSC</a></li>
                                            <li><a href="course-details.php">TUTION</a></li>
                                            <li><a href="course-details.php">Web Design/Development</a></li>
                            </ul>
                            <h4>User Account</h4>
                            <ul>
                                <li><a href="#!" data-toggle="modal" data-target="#modal1">Sign In</a></li>
                                <li><a href="#!" data-toggle="modal" data-target="#modal2">Register</a></li>
                            </ul>
                            <h4>All Pages</h4>
                            <ul>
                                <li><a href="index-2.php">Home</a></li>
                                <li><a href="about.php">About us</a></li>
                                <li><a href="admission.php">Admission</a></li>
                                <li><a href="all-courses.php">All courses</a></li>
                                <li><a href="course-details.php">Course details</a></li>
                          
                                <li><a href="contact-us.php">Contact us</a></li>
                            </ul>
                            <h4>User Profile</h4>
                            <ul>
                                <li><a href="dashboard.php">User profile</a></li>
                                <li><a href="db-courses.php">Courses</a></li>
                                <li><a href="db-exams.php">Exams</a></li>
                                <li><a href="db-profile.php">Prfile</a></li>
                                <li><a href="db-time-line.php">Time line</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>