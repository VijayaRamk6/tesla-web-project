<!DOCTYPE php>
<php>
<body>
<?php include"sdb-course-view/body.php" ?>
</body>
</php>
