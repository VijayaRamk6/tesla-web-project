    <section>
        <div class="container com-sp">
            <div class="row">
                <div class="cor about-sp">
                    <div class="ed-about-tit">
                        <div class="con-title">
                            <h2>Blog <span> Posts</span></h2>
                            <p>Fusce id sem at ligula laoreet hendrerit venenatis sed purus. Ut pellentesque maximus lacus, nec pharetra augue.</p>
                        </div>
                        <div>
                            <div class="ho-event pg-eve-main pg-blog">
                                <ul>
                                    <li>
                                        <div class="ho-ev-date pg-eve-date"><span>07</span><span>jan,2018</span>
                                        </div>
                                        <div class="pg-eve-desc pg-blog-desc">
                                            <a href="event-register.php">
                                                <h4>Best Study Spots on Campus</h4>
                                            </a>
											<img src="images/blog/6.jpg" alt="">
											<div class="share-btn blog-share-btn">
												<ul>
													<li><a href="#"><i class="fa fa-facebook fb1"></i> Share On Facebook</a>
													</li>
													<li><a href="#"><i class="fa fa-twitter tw1"></i> Share On Twitter</a>
													</li>
													<li><a href="#"><i class="fa fa-google-plus gp1"></i> Share On Google Plus</a>
													</li>
												</ul>
											</div>
                                            <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
                                            <span>9:15 am – 5:00 pm</span>
                                        </div>
                                        <div class="pg-eve-reg pg-blog-reg">
                                            <a href="blog-details.php">Read more</a>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ho-ev-date pg-eve-date"><span>07</span><span>jan,2018</span>
                                        </div>
                                        <div class="pg-eve-desc pg-blog-desc">
                                            <a href="event-register.php">
                                                <h4>Recaps of Student Events on Campus</h4>
                                            </a>
											<img src="images/blog/2.jpg" alt="">
											<div class="share-btn blog-share-btn">
												<ul>
													<li><a href="#"><i class="fa fa-facebook fb1"></i> Share On Facebook</a>
													</li>
													<li><a href="#"><i class="fa fa-twitter tw1"></i> Share On Twitter</a>
													</li>
													<li><a href="#"><i class="fa fa-google-plus gp1"></i> Share On Google Plus</a>
													</li>
												</ul>
											</div>
                                            <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
                                            <span>9:15 am – 5:00 pm</span>
                                        </div>
                                        <div class="pg-eve-reg pg-blog-reg">
                                            <a href="blog-details.php">Read more</a>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="ho-ev-date pg-eve-date"><span>07</span><span>jan,2018</span>
                                        </div>
                                        <div class="pg-eve-desc pg-blog-desc">
                                            <a href="event-register.php">
                                                <h4>School Project Highlights</h4>
                                            </a>
											<img src="images/blog/3.jpg" alt="">
											<div class="share-btn blog-share-btn">
												<ul>
													<li><a href="#"><i class="fa fa-facebook fb1"></i> Share On Facebook</a>
													</li>
													<li><a href="#"><i class="fa fa-twitter tw1"></i> Share On Twitter</a>
													</li>
													<li><a href="#"><i class="fa fa-google-plus gp1"></i> Share On Google Plus</a>
													</li>
												</ul>
											</div>
                                            <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
                                            <span>9:15 am – 5:00 pm</span>
                                        </div>
                                        <div class="pg-eve-reg pg-blog-reg">
                                            <a href="blog-details.php">Read more</a>
                                        </div>
                                    </li>
									<li>
                                        <div class="ho-ev-date pg-eve-date"><span>07</span><span>jan,2018</span>
                                        </div>
                                        <div class="pg-eve-desc pg-blog-desc">
                                            <a href="event-register.php">
                                                <h4>Sample Semester Schedule</h4>
                                            </a>
											<img src="images/blog/4.jpg" alt="">
											<div class="share-btn blog-share-btn">
												<ul>
													<li><a href="#"><i class="fa fa-facebook fb1"></i> Share On Facebook</a>
													</li>
													<li><a href="#"><i class="fa fa-twitter tw1"></i> Share On Twitter</a>
													</li>
													<li><a href="#"><i class="fa fa-google-plus gp1"></i> Share On Google Plus</a>
													</li>
												</ul>
											</div>
                                            <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
                                            <span>9:15 am – 5:00 pm</span>
                                        </div>
                                        <div class="pg-eve-reg pg-blog-reg">
                                            <a href="blog-details.php">Read more</a>
                                        </div>
                                    </li>
									 <li>
                                        <div class="ho-ev-date pg-eve-date"><span>07</span><span>jan,2018</span>
                                        </div>
                                        <div class="pg-eve-desc pg-blog-desc">
                                            <a href="event-register.php">
                                                <h4>Experience of Studying Abroad</h4>
                                            </a>
											<img src="images/blog/5.jpg" alt="">
											<div class="share-btn blog-share-btn">
												<ul>
													<li><a href="#"><i class="fa fa-facebook fb1"></i> Share On Facebook</a>
													</li>
													<li><a href="#"><i class="fa fa-twitter tw1"></i> Share On Twitter</a>
													</li>
													<li><a href="#"><i class="fa fa-google-plus gp1"></i> Share On Google Plus</a>
													</li>
												</ul>
											</div>
                                            <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
                                            <span>9:15 am – 5:00 pm</span>
                                        </div>
                                        <div class="pg-eve-reg pg-blog-reg">
                                            <a href="blog-details.php">Read more</a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="pg-pagina">
                            <ul class="pagination">
                                <li class="disabled"><a href="#!"><i class="fa fa-angle-left" aria-hidden="true"></i></a></li>
                                <li class="active"><a href="#!">1</a></li>
                                <li class="waves-effect"><a href="#!">2</a></li>
                                <li class="waves-effect"><a href="#!">3</a></li>
                                <li class="waves-effect"><a href="#!">4</a></li>
                                <li class="waves-effect"><a href="#!">5</a></li>
                                <li class="waves-effect"><a href="#!"><i class="fa fa-angle-right" aria-hidden="true"></i></a></li>
                            </ul>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>