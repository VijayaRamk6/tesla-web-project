<?php
// Replace these values with your actual username and password
$validUsername = "vijayaram";
$validPassword = "ram@369";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Perform basic validation
    if ($username == $validUsername && $password == $validPassword) {
        // Redirect to the admin panel or another page on successful login
        header("Location: admin.php");
        exit();
    } else {
        // Handle invalid login (show an error message or redirect back to the login page)
        echo "Invalid username or password";
    }
}
?>
