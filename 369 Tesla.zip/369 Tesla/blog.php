<!DOCTYPE php>
<php lang="en">

<?php include"blog/head.php" ?>

<body>

    <!-- MOBILE MENU -->
    <?php include"blog/mobile menu.php" ?>

    <!--HEADER SECTION-->
    <?php include"blog/header.php" ?>
    <!--END HEADER SECTION-->

    <!--SECTION START-->
    <?php include"blog/section.php" ?>
    <!--SECTION END-->


    <!--SECTION START-->
    <?php include"blog/section1.php" ?>
    <!--SECTION END-->

    <!--HEADER SECTION-->
    <?php include"blog/header1.php" ?>
    <!--END HEADER SECTION-->

    <!--HEADER SECTION-->
    <?php include"blog/header2.php" ?>
    <!--END HEADER SECTION-->

    <!--SECTION LOGIN, REGISTER AND FORGOT PASSWORD-->
    <?php include"blog/login.php" ?>

    <!--Import jQuery before materialize.js-->
    <?php include"blog/js.php" ?>
</body>


</php>