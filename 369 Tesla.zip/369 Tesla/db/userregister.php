<?php
session_start(); // Start a session (if not already started)

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "teslaorg_short";

    // Create a database connection
    $conn = new mysqli($db_host, $db_username, $db_password, $db_name);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the form submission is for registration
    if (isset($_POST["register"])) {
        // Retrieve and sanitize user input from the registration form
        $username = $_POST["username"];
        $email = $_POST["email"];
        $password = password_hash($_POST["password"], PASSWORD_BCRYPT); // Hash the password

        // Prepare and execute an SQL statement to insert user registration data into the database
        $sql = "INSERT INTO userregistration (username, email, password) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $username, $email, $password);

        if ($stmt->execute()) {
            // Registration successful
            echo "Registration successful.";
        } else {
            // Database error
            echo "Error: " . $stmt->error;
        }

        // Close the database connection
        $stmt->close();
    } elseif (isset($_POST["login"])) {
        // Retrieve user input from the login form
        $login_username = $_POST["login_username"];
        $login_password = $_POST["login_password"];

        // Prepare and execute an SQL statement to check if the user exists
        $sql = "SELECT id, username, password FROM userregistration WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $login_username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            // User found, verify password
            $row = $result->fetch_assoc();
            $stored_password = $row["password"];

            // Verify the entered password against the stored hashed password
            if (password_verify($login_password, $stored_password)) {
                // Passwords match, set a session variable to indicate successful login
                $_SESSION["user_id"] = $row["id"]; // Store user ID or any relevant info (use "id" instead of "user_id")
                echo "Login successfully";
            } else {
                // Passwords do not match
                echo "Incorrect password. Please try again.";
            }
        } else {
            // User not found
            echo "User not found. Please check your username.";
        }

        // Close the database connection
        $stmt->close();
    }
    // Close the database connection
    $conn->close();
}
?>
