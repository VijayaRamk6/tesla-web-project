<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "teslaorg_short";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process the form data when the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = $_POST["Username"];
    $lastname = $_POST["Lastname"];
    $dob = $_POST["DOB"];
    $place = $_POST["Place"];
    $area = $_POST["Area"];
    $district = $_POST["District"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $subject = $_POST["subject"];

    // SQL query to insert data into the 'users' table using prepared statements
    $sql = "INSERT INTO users (firstname, lastname, dob, place, area, district, email, phone, subject)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Create a prepared statement
    $stmt = $conn->prepare($sql);

    // Bind parameters to the prepared statement
    $stmt->bind_param("sssssssss", $firstname, $lastname, $dob, $place, $area, $district, $email, $phone, $subject);

    try {
        // Attempt to execute the prepared statement and handle success or errors
        if ($stmt->execute()) {
            // Data inserted successfully
            $stmt->close();
            $conn->close();

            // Redirect to contact-us.php
            header("Location: /all-courses.php");
            exit;
        } else {
            die("Error in executing statement: " . $stmt->error);
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    } finally {
        // Close the database connection in the finally block
        $stmt->close();
        $conn->close();
    }
}
?>
