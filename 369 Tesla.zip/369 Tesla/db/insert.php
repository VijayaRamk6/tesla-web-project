<?php
require_once 'conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];

    try {
        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $sql = "INSERT INTO form_submissions (name, email, subject, message) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {
            die("Error in preparing statement: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $subject, $message);

        if (mysqli_stmt_execute($stmt)) {
            // Data inserted successfully
            mysqli_stmt_close($stmt);
            mysqli_close($conn);

            // Redirect to form.html
           header("Location: /contact-us.php");
exit;

            exit;
        } else {
            die("Error in executing statement: " . mysqli_error($conn));
        }

        // Close connection
        mysqli_close($conn);
    } catch (Exception $e) {
        // Handle any exceptions or errors if needed
        echo "Exception: " . $e->getMessage();
    }
}
?>
