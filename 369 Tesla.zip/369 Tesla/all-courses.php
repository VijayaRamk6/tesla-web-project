<!DOCTYPE php>
<php lang="en">

<?php include"all-courses/head.php" ?>

<body>

    <!-- MOBILE MENU -->
    <?php include"all-courses/mobile menu.php" ?>

    <!--HEADER SECTION-->
    <?php include"all-courses/header.php" ?>
    <!--END HEADER SECTION-->
    <?php include"all-courses/sec.php" ?>

    <!--SECTION START-->
    <?php include"all-courses/section start.php" ?>
    <!--SECTION END-->

    <!--HEADER SECTION-->
    <?php include"all-courses/header1.php" ?>
    <!--END HEADER SECTION-->

    <!--HEADER SECTION-->
    <?php include"all-courses/header2.php" ?>
    <!--END HEADER SECTION-->

    <!--SECTION LOGIN, REGISTER AND FORGOT PASSWORD-->
    <?php include"all-courses/login.php" ?>

    <!--Import jQuery before materialize.js-->
    <?php include"all-courses/js.php" ?>
</body>


</php>