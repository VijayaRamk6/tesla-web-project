<section>
        <div class="full-bot-book">
            <div class="container">
                <div class="row">
                    <div class="bot-book">
                        <div class="col-md-2 bb-img">
                            <img src="images/3.png" alt="">
                        </div>
                        <div class="col-md-7 bb-text">
                            <h4>If You Already The Member of Test Series </h4>
                            <p>You can express your satisfaction with the test series and mention how it has helped you prepare for your exams.</p>
                        </div>
                        <div class="col-md-3 bb-link">
                            <a href="https://net.369tesla.in/login.php">Book This Course</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>