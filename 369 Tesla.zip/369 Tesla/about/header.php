<section>
        <!-- TOP BAR -->
        <div class="ed-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ed-com-t1-left">
                            <ul>
                                <li><a href="#">Contact: RMTC Shed ,Amaravati Nagar,Hero Showroom UpStairs</a>
                                </li>
                                <li><a href="#">Phone: 8870334411</a>
                                </li>
                            </ul>
                        </div>
                        <div class="ed-com-t1-right">
                            <ul>
                                <li><a href="#!" data-toggle="modal" data-target="#modal1">Sign In</a>
                                </li>
                                <li><a href="#!" data-toggle="modal" data-target="#modal2">Sign Up</a>
                                </li>
                            </ul>
                        </div>
                        <div class="ed-com-t1-social">
                            <ul>
                            <li>
                               <a href="https://www.youtube.com/@369Tesla"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="https://369tesla.in/"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="https://twitter.com/369teslax"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- LOGO AND MENU SECTION -->
        <div class="top-logo" data-spy="affix" data-offset-top="250">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="wed-logo">
                            <a href="index-2.php"><img src="images/logo.png" alt="" />
                            </a>
                        </div>
                        <div class="main-menu">
                            <ul>
                                <li><a href="index-2.php">Home</a>
                                </li>
                                <li class="about-menu">
                                    <a href="about.php" class="mm-arr">About us</a>
                                    <!-- MEGA MENU 1 -->
                                    <div class="mm-pos">
                                        <div class="about-mm m-menu">
                                            <div class="m-menu-inn">
                                                <div class="mm1-com mm1-s1">
                                                    <div class="ed-course-in">
                                                        <a class="course-overlay menu-about" href="admission.php">
                                                            <img src="images/h-about.jpg" alt="">
                                                            <span>Academics</span>
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="mm1-com mm1-s2">
                                                    <p>At 369 Tesla Coaching Centre, we are committed to providing you the best in the chess, vedic mathematics, software training, web designing and Development.</p>
                                                    <a href="about.php" class="mm-r-m-btn">Read more</a>
                                                </div>
                                                <div class="mm1-com mm1-s3">
                                                    <ul>
                                                     
                                                        <li><a href="course-details.php">Course details</a></li>
                                                        <li><a href="about.php">About</a></li>
                                                        <li><a href="admission.php">Admission</a></li>
                                                    </ul>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="admi-menu">
                                    <a href="admission.php" class="mm-arr">Admission</a>
                                    <!-- MEGA MENU 1 -->
                                </li>
                                <li><a href="all-courses.php">All Courses</a></li>
                                <!--<li><a class='dropdown-button ed-sub-menu' href='#' data-activates='dropdown1'>Courses</a></li>-->
                                <li class="cour-menu">
                                    <a href="#!" class="mm-arr">All Pages</a>
                                    <!-- MEGA MENU 1 -->
                                    <div class="mm-pos">
                                        <div class="cour-mm m-menu">
                                            <div class="m-menu-inn">
                                                <div class="mm1-com mm1-cour-com mm1-s3">
													<h4>INDEX</h4>
                                                    <ul>
                                                
														<li><a href="all-courses.php">All Courses</a></li>
														<li><a href="course-details.php">Course Details</a></li>
														<li><a href="about.php">About us</a></li>
													
														
														<li><a href="blog.php">blog</a></li>
														<li><a href="blog-details.php">blog details</a></li>
														<li><a href="contact-us.php">contact us</a></li>
													
										
                                                    </ul>
                                                </div>
                                                <div class="mm1-com mm1-cour-com mm1-s3">
													<h4>Facilities</h4>
                                                    <ul>
														<li><a href="facilities.php">facilities</a></li>
														<li><a href="facilities-detail.php">facilities detail</a></li>
											
                                                    </ul>
												

                                                </div>
                                                <div class="mm1-com mm1-cour-com mm1-s3">
													<h4>ADMIN </h4>
                                                    <ul>
														<li><a href="form.php">admin</a></li>
                                                    </ul>
                                                </div>
                                                
                                               
                                            </div>
                                        </div>
                                    </div>
                                </li>
                           

                                <li><a href="contact-us.php">Contact us</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="all-drop-down-menu">

                    </div>

                </div>
            </div>
        </div>
        <div class="search-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="search-form">
                            <form>
                                <div class="sf-type">
                                    <div class="sf-input">
                                        <input type="text" id="sf-box" placeholder="Search course and discount courses">
                                    </div>
                                    <div class="sf-list">
                                        <ul>
                                        <li><a href="course-details.php">computer Science</a></li>
                                            <li><a href="course-details.php">IIT</a></li>
                                            <li><a href="course-details.php">JEE</a></li>
                                            <li><a href="course-details.php">NEET</a></li>
                                            <li><a href="course-details.php">TNPSC</a></li>
                                            <li><a href="course-details.php">TUTION</a></li>
                                            <li><a href="course-details.php">Web Design/Development</a></li>
                                    </div>
                                </div>
                                <div class="sf-submit">
                                    <input type="submit" value="Search Course">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>