<!DOCTYPE php>
<php lang="en">


<?php include"index-1/head.php" ?>

<body>

    <!-- MOBILE MENU -->
    <?php include"index-1/mobile menu.php" ?>
    <!--HEADER SECTION-->
    <?php include"index-1/header.php" ?>
    <!--END HEADER SECTION-->

    <!-- SLIDER -->
    <?php include"index-1/slider.php" ?>
   
    <!-- DISCOVER MORE -->
    <?php include"index-1/discover.php" ?>

    <!-- POPULAR COURSES -->
    <?php include"index-1/popular.php" ?>

    <!-- UPCOMING EVENTS -->
    <?php include"index-1/upcomming.php" ?>

    <!-- NEWS AND EVENTS -->
    <?php include"index-1/news.php" ?>

    <!-- FOOTER COURSE BOOKING -->
    <?php include"index-1/footer.php" ?>

    <!-- FOOTER -->
    <?php include"index-1/footer1.php" ?>
    <!-- COPY RIGHTS -->
    <?php include"index-1/copy.php" ?>

    <!--SECTION LOGIN, REGISTER AND FORGOT PASSWORD-->
    <?php include"index-1/login.php" ?>

    <!--Import jQuery before materialize.js-->
    <?php include"index-1/js.php" ?>
</body>


</php>