<!DOCTYPE php>
<php lang="en">


<?php include"course-details/head.php" ?>

<body>

    <!-- MOBILE MENU -->
    <?php include"course-details/mobile menu.php" ?>

    <!--HEADER SECTION-->
   <?php include"course-details/header.php" ?>
    <!--END HEADER SECTION-->

    <!--SECTION START-->
    <?php include"course-details/section.php" ?>
    <!--SECTION END-->


    <!--SECTION START-->
    <?php include"course-details/section1.php" ?>
    <!--SECTION END-->

    <!--HEADER SECTION-->
    <?php include"course-details/header1.php" ?>
    <!--END HEADER SECTION-->

    <!--HEADER SECTION-->
    <?php include"course-details/header2.php" ?>
    <!--END HEADER SECTION-->

    <!--SECTION LOGIN, REGISTER AND FORGOT PASSWORD-->
    <?php include"course-details/login.php" ?>

    <!--Import jQuery before materialize.js-->
    <?php include"course-details/js.php" ?>
</body>


</php>